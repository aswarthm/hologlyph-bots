#!/usr/bin/env python3
'''
*****************************************************************************************
*
*        		===============================================
*           		Hologlyph Bots (HB) Theme (eYRC 2023-24)
*        		===============================================
*
*  This script is to implement Task 2B of Hologlyph Bots (HB) Theme (eYRC 2023-24).
*  
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or 
*  breach of the terms of this agreement.
*
*****************************************************************************************
'''


# Team ID:		    hb_1036
# Author List:		[ M Aswartha Reddy, D K Bharath Reddy, Pulkit Dhamija, Sangeeta Prasad ]
# Filename:		    bot_controller.py
# Functions:
#			[ Comma separated list of functions in this file ]
# Nodes:		
#                   Subs: [ 'hb_bot_{self.bot_id}/goal', '/detected_aruco_{self.bot_id}' ]
#                   Pubs: [ "/hb_bot_{self.bot_id}/rear_wheel_force", "/hb_bot_{self.bot_id}/left_wheel_force", "/hb_bot_{self.bot_id}/right_wheel_force" ]


################### IMPORT MODULES #######################

import rclpy
from rclpy.node import Node
import time
import math
from tf_transformations import euler_from_quaternion
from my_robot_interfaces.msg import Goal             

from geometry_msgs.msg import Twist
from geometry_msgs.msg import Wrench
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Pose2D    
import numpy as np  
from std_msgs.msg import Bool
from std_srvs.srv import Empty

from geometry_msgs.msg import Vector3


isSimulator = False



# bot_id = 2

bot_ids = [1, 2, 3]

bot_done = { # if all are 1 then end run
    1: 0,
    2: 0,
    3: 0
}

bot_is_home = {
    1: 1,
    2: 0,
    3: 1
}

bot_home_flag = 0

class HBController(Node):
    def __init__(self, bot_id):
        self.bot_id = bot_id
        super().__init__(f'hb_controller{self.bot_id}')
        ##disable#self.get_logger().info(f"{self.bot_id} id controller start")

        self.create_timer(0.1, self.timerCb)

        self.goalsReceived = False        
        self.index = 0
        self.flag = 0
        self.locationReceived = False

        

        # Initialise the required variables
        self.bot_x_goals = []
        self.bot_y_goals = []
        self.bot_theta_goal = 0.0

        self.bot_home = {
            1: [397.0, 455.0],
            2: [243.0, 448.0],
            3: [93.0, 440.0]
        }


        # Initialze Publisher and Subscriber
        # NOTE: You are strictly NOT-ALLOWED to use "cmd_vel" or "odom" topics in this task
	    #	Use the below given topics to generate motion for the robot.
	    #   /hb_bot_1/left_wheel_force,
	    #   /hb_bot_1/right_wheel_force,
	    #   /hb_bot_1/left_wheel_force

        #Similar to this you can create subscribers for hb_bot_2 and hb_bot_3
        self.subscription_goal = self.create_subscription(Goal,  
                                                     f'hb_bot_{self.bot_id}/goal',  
                                                     self.goalCallBack,  # Callback function to handle received messages
                                                     10  # QoS profile, here it's 10 which means a buffer size of 10 messages
        )  
        self.subscription_aruco = self.create_subscription(Pose2D, 
                                                    f"pen{self.bot_id}_pose",
                                                    self.arucoCb,
                                                    10)
        

        if(isSimulator):
            self.rear_wheel_publisher = self.create_publisher(Wrench,
                                                            f"/hb_bot_{self.bot_id}/rear_wheel_force",
                                                            10)
            self.left_wheel_publisher = self.create_publisher(Wrench,
                                                            f"/hb_bot_{self.bot_id}/left_wheel_force",
                                                            10)        
            self.right_wheel_publisher = self.create_publisher(Wrench,
                                                            f"/hb_bot_{self.bot_id}/right_wheel_force",
                                                            10)
            
        else:
            self.cmd_vel_publisher = self.create_publisher(Vector3,
                                                            f"/hb_bot_{self.bot_id}/cmd_vell",
                                                            10)


        self.pen_down_publisher = self.create_publisher(Bool, 
                                                        f"/pen{self.bot_id}_down",
                                                        10)
        



        self.hb_x = 250.0
        self.hb_y = 250.0
        self.hb_theta = 0.0

        if(isSimulator):
            self.k_mult = 40.0
            self.kp = 0.1*self.k_mult #1.5 # 5.5 gives 78
            self.ka = 1.8*self.k_mult #2.8 #1.8

            self.linear_tolerance = 4.5 #4.5 # linear tolerance
            self.angular_tolerance = math.radians(4) # degree tolerance
        else:
            self.k_mult = 40.0
            self.kp = 0.1*self.k_mult #1.5 # 5.5 gives 78
            self.ka = 2.8*self.k_mult #2.8 #1.8

            self.linear_tolerance = 10.0 #4.5 # linear tolerance
            self.angular_tolerance = math.radians(8) # degree tolerance

        self.left_force = 0.0
        self.right_force = 0.0
        self.rear_force = 0.0

        # For maintaining control loop rate.
        self.rate = self.create_rate(100)

    def arucoCb(self, msg):
        '''
        Purpose:
        ---
        Callback function when robot's position changes. Updates local variables with current x,y,theta

        Input Arguments:
        ---
        self:HBController
        odom:Pose2D updated odometry of robot

        Returns:
        ---
        None

        Example call:
        ---
        -
        '''
        if(self.bot_id == 3):
            pass
            # self.get_logger().info(str(msg))
        if(self.locationReceived == False):
            self.locationReceived = True

        self.hb_x = msg.x
        self.hb_y = msg.y
        self.hb_theta = msg.theta - math.radians(90)

    def inverse_kinematics(self, velocity):
        '''
        Purpose:
        ---
        Calculate inverse kinematics for the desired velocity

        Input Arguments:
        ---
        self:HBController
        velocity:numpy.ndarray in the format [theta, x, y]

        Returns:
        ---
        force:numpy.ndarray in the format [rear_wheel, left_wheel, right_wheel]

        Example call:
        ---
        force = hb_controller.inverse_kinematics(velocity)
        '''
        ############ ADD YOUR CODE HERE ############

        # INSTRUCTIONS & HELP : 
        #	-> Use the target velocity you calculated for the robot in previous task, and
        #	Process it further to find what proportions of that effort should be given to 3 individuals wheels !!
        #	Publish the calculated efforts to actuate robot by applying force vectors on provided topics
        ############################################

        ik_matrix = np.array([
                                [1.0,1.0,0.0],
                                [1.0,-math.cos(math.pi/3.0),-math.sin(math.pi/3.0)],
                                [1.0,-math.cos(math.pi/3.0),math.sin(math.pi/3.0)]
                            ])
        # velocity is in the format [theta, x, y]
        # force is in the format [rear_wheel, left_wheel, right_wheel]
        force = np.dot(ik_matrix, velocity).flatten()

        return force

    def goalCallBack(self, msg):
        '''
        Purpose:
        ---
        Callback function when bew goals are received. Updates array with goals to be reached
        Sleeps for a certian amount of time to prevent collision

        Input Arguments:
        ---
        self:HBController
        msg:Goal goal list of bot containing x, y and theta

        Returns:
        ---
        None

        Example call:
        ---
        -
        '''
        if(self.goalsReceived == False):
            self.bot_x_goals = msg.x
            self.bot_y_goals = msg.y

            # self.bot_x_goals = [x].append(msg.x)
            # self.bot_y_goals = [y].append(msg.y)
            self.bot_theta_goal = msg.theta

            self.goalsReceived = True

            # time.sleep(self.bot_id*3) #add some delay before starting to prevent collision

            # for i in range(5*self.bot_id):
            #     time.sleep(0.4)
    
    def get_goal(self):
        '''
        Purpose:
        ---
        Returns the next goal for the bot and if all the goals have been reached i.e. end of list

        Input Arguments:
        ---
        self:HBController

        Returns:
        ---
        [goal_x, goal_y, goal_theta, end_of_list]

        Example call:
        ---
        hb_controller.get_goal()
        '''
        goal_x = self.bot_x_goals[self.index]
        goal_y = self.bot_y_goals[self.index]
        goal_theta = self.bot_theta_goal

        end_of_list = int((1 + self.index) >= len(self.bot_x_goals))

        return [goal_x, goal_y, goal_theta, end_of_list]

    
    def map(self, value, leftMin, leftMax, rightMin, rightMax):
        # Figure out how 'wide' each range is
        leftSpan = leftMax - leftMin
        rightSpan = rightMax - rightMin

        # Convert the left range into a 0-1 range (float)
        valueScaled = float(value - leftMin) / float(leftSpan)

        # Convert the 0-1 range into a value in the right range.
        return 180 - (rightMin + (valueScaled * rightSpan))
    
    def publish_force_vectors(self, force):
        '''
        Purpose:
        ---
        Publishes the forces to appropriate wheels, i.e. [rear, left, right]

        Input Arguments:
        ---
        self:HBController
        force:numpy.ndarray in the format [rear, left, right]

        Returns:
        ---
        None

        Example call:
        ---
        hb_controller.publish_force_vectors(force)
        '''

        if(isSimulator):
            #for simulator
            force_rear = Wrench()
            force_left = Wrench()
            force_right = Wrench()

            force_rear.force.y = force[0]
            force_left.force.y = force[1]
            force_right.force.y = force[2]


            self.rear_wheel_publisher.publish(force_rear)
            self.left_wheel_publisher.publish(force_left)
            self.right_wheel_publisher.publish(force_right)
        else:
            #for hardware
            cmd_vel = Vector3()


            cmd_vel.x = self.map(force[0], -100.0, 100.0, 0.0, 180.0)
            cmd_vel.y = self.map(force[1], -100.0, 100.0, 0.0, 180.0)
            cmd_vel.z = self.map(force[2], -100.0, 100.0, 0.0, 180.0)
            
            self.cmd_vel_publisher.publish(cmd_vel)


        if(self.bot_id == 3):
            pass
            # self.get_logger().info(f"{force[0]} {force[1]} {force[2]}")
    
    def goal_reached(self, frame):
        '''
        Purpose:
        ---
        Checks if the bot is within acceptable limits, which tells if the bot has reached its goal

        Input Arguments:
        ---
        self:HBController
        frame:numpy.ndarray in the format [error_theta, error_x, error_y]

        Returns:
        ---
        True if bot has reached goal
        False otherwise

        Example call:
        ---
        if(hb_controller.goal_reached(frame)):
            # do something
        '''
        error_theta = frame[0]

        error_linear = math.sqrt(math.pow(frame[1], 2) + math.pow(frame[2], 2))
        ##disable#self.get_logger().info(str(error_linear))

        if(abs(error_theta) < self.angular_tolerance and abs(error_linear) < self.linear_tolerance):
        # if(abs(error_theta) < self.angular_tolerance and abs(frame[1]) < self.linear_tolerance and abs(frame[2]) < self.linear_tolerance):
            return True
        
        return False
    
    def stop_bot(self):
        '''
        Purpose:
        ---
        Stops the bot after reaching goal, or in case of an emergency

        Input Arguments:
        ---
        self:HBController

        Returns:
        ---
        None

        Example call:
        ---
        hb_controller.stop_bot()
        '''

        msg = Bool()
        msg.data = False #do penup
        bot_done[self.bot_id] = 1
        self.pen_down_publisher.publish(msg)
        self.publish_force_vectors(np.array([0.0, 0.0, 0.0]))
        # time.sleep(2)
        # self.publish_force_vectors(np.array([0.0, 0.0, 0.0]))

    def normalize_velocity(self, velocity):
        '''
        Purpose:
        ---
        Makes sure the velocities are within acceptable range to prevent unpredictable behaviour

        Input Arguments:
        ---
        self:HBController
        velocity: List

        Returns:
        ---
        velocity: List

        Example call:
        ---
        hb_controller.normalize_velocity(velocity)
        '''
        max_vel = 100.0

        velocity[1] = max(-max_vel, min(velocity[1], max_vel))
        velocity[2] = max(-max_vel, min(velocity[2], max_vel))
        
        return velocity


    def allBotsHome(self):
        global bot_home_flag

        for i in bot_ids:
            if(bot_is_home[i] == 0):
                return False
        
        if(bot_home_flag == 0):
            bot_home_flag = 1
            # time.sleep((self.bot_id)*3)

        return True

    
    def timerCb(self):
        '''
        Purpose:
        ---
        Callback function to run main loop of the controller
        simplifies multi threading

        Input Arguments:
        ---
        self:HBController

        Returns:
        ---
        None

        Example call:
        ---
        -
        '''
        # Check if the goals have been received
        if self.goalsReceived == True and self.locationReceived == True:
            try:
                # response from the service call
                response = self.get_goal()
            except Exception as e:
                #self.get_logger().info('Goal call failed %r' % (e,))
                pass
            else:
                #########           GOAL POSE             #########
                x_goal      = response[0] #+ 250.0
                y_goal      = response[1] #+ 250.0
                theta_goal  = response[2]
                self.flag = response[3]
                ####################################################

                # self.get_logger().info(f'{x_goal} {y_goal} {math.degrees(theta_goal)}')
                ##disable###disable#self.get_logger().info(f'cur {self.hb_x} {self.hb_y} {math.degrees(self.hb_theta)}')
                
                # Calculate Error from feedback
                error_x = x_goal - self.hb_x
                error_y = y_goal - self.hb_y
                error_theta = theta_goal - self.hb_theta

                # Change the frame by using Rotation Matrix (If you find it required)
                frame = np.array([error_theta, error_x, error_y])

                rot_matrix = np.array([
                                        [1, 0, 0],
                                        [0, math.cos(self.hb_theta), -math.sin(self.hb_theta)],
                                        [0, -math.sin(self.hb_theta), -math.cos(self.hb_theta)],
                                      ])
                global_error = np.dot(frame, rot_matrix).flatten()
                # ##disable###disable#self.get_logger().info(str(global_error))
            
                # Calculate the required velocity of bot for the next iteration(s)
                k = np.array([self.ka, self.kp, self.kp])
                velocity = np.multiply(global_error, k)
                velocity = self.normalize_velocity(velocity)
                ##disable###disable#self.get_logger().info(str(velocity))
                
                # Find the required force vectors for individual wheels from it.(Inverse Kinematics)
                force = self.inverse_kinematics(velocity)

                # Apply appropriate force vectors
                self.publish_force_vectors(force)


                # Modify the condition to Switch to Next goal (given position in pixels instead of meters)
                if(self.goal_reached(frame)):
                    # self.stop_bot()
                    self.get_logger().info("gigi")

                    if(self.index == 0):
                        bot_is_home[self.bot_id] = 1
                        self.stop_bot()
                        while(self.allBotsHome() == False):
                            pass
                        else:
                            if(self.bot_id == 3):
                                time.sleep(12)
                            else:
                                time.sleep(8)
                        self.get_logger().info(f"{self.bot_id}index 0")

                    if(self.index == 1):
                        msg = Bool()
                        msg.data = True #do pendown
                        self.pen_down_publisher.publish(msg)
                        self.get_logger().info(f"{self.bot_id}index 1")
                    self.get_logger().info(f"{self.bot_id} {self.index}")

                    
                    if(self.index == len(self.bot_x_goals)-1):
                        msg = Bool()
                        msg.data = False #do penup
                        bot_done[self.bot_id] = 1
                        self.pen_down_publisher.publish(msg)

                        self.goalsReceived = False
                        self.stop_bot()
                        self.destroy_node()
                                                                
                    # if(self.finished_run()):
                    #     request = Empty.Request()
                    #     self.client.call_async(request)

                    ############     DO NOT MODIFY THIS       #########
                    self.index += 1
                    if self.flag == 1 :
                        self.index = 0
                    ####################################################


class StopService(Node):
    def __init__(self):
        super().__init__(f'stop_service_node_start')
        self.client = self.create_client(Empty, 'Stop_Flag')
        self.create_timer(0.1, self.timerCb)
    
    def finished_run(self):

        for i in bot_ids:
            if(bot_done[i] == 0):
                return False
            
        return True
    
    def timerCb(self):
        if(self.finished_run()):
            request = Empty.Request()
            self.client.call_async(request)
            self.get_logger().info("Finished Run")

            self.destroy_node()


def main(args=None):
    rclpy.init(args=args)

    executor = rclpy.executors.MultiThreadedExecutor()

    hb_controller_1 = HBController(bot_id=1)
    hb_controller_2 = HBController(bot_id=2)
    hb_controller_3 = HBController(bot_id=3)


    executor.add_node(hb_controller_1)
    executor.add_node(hb_controller_2)
    executor.add_node(hb_controller_3)


    stop_serv = StopService()

    executor.add_node(stop_serv)

    try:
        executor.spin()

    finally:
        executor.shutdown()

        hb_controller_1.destroy_node()
        hb_controller_2.destroy_node()
        hb_controller_3.destroy_node()

        stop_serv.destroy_node()
        rclpy.shutdown()
       
    # # Main loop
    # while rclpy.ok():
    #     # Spin once to process callbacks
    #     rclpy.spin_once(hb_controller)
    # # Destroy the node and shut down ROS
    # hb_controller.destroy_node()
    # rclpy.shutdown()

# Entry point of the script
if __name__ == '__main__':
    main()